NAME = Clean Strike

Scope of this project:

Each player will get a subsequent attempts after a strike
Turn does not extend for single player on scoring.
The points will be decided as per the 5 different outcomes from the requirement document.
The final score will be settled as per the senarios given in requirement document
Rules to run the program:

TestCases are ran in CLI in Two ways

Plays a game with variable declared as fileIO during class initialization. Can alter the variable to get various scenarios of output's.

python TestCase.py

The third argument passes filename with player scenarios, The output is generated in output.csv file.

python TestCase.py sheet.csv